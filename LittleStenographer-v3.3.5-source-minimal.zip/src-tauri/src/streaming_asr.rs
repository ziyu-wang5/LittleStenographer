use sherpa_onnx::{OnlineRecognizer, OnlineRecognizerConfig};
use std::path::{Path, PathBuf};

pub struct StreamingRecognizer {
    recognizer: OnlineRecognizer,
    stream: sherpa_onnx::OnlineStream,
    committed: String,
    last_hypothesis: String,
}

pub fn model_dir(resource_dir: &Path) -> PathBuf {
    model_dir_for(resource_dir, "streaming-paraformer")
}

pub fn model_dir_for(resource_dir: &Path, folder: &str) -> PathBuf {
    let candidates = [
        resource_dir.join("models").join(folder), resource_dir.join(folder),
        resource_dir.join("resources").join("models").join(folder),
        PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("resources").join("models").join(folder),
    ];
    candidates
        .iter()
        .find(|path| folder_available(folder, path))
        .cloned()
        .unwrap_or_else(|| candidates[0].clone())
}

fn folder_available(folder: &str, model_dir: &Path) -> bool {
    let required: &[&str] = if folder == "streaming-zipformer-ctc-zh" {
        &["tokens.txt", "model.int8.onnx"]
    } else {
        &["tokens.txt", "encoder.int8.onnx", "decoder.int8.onnx"]
    };
    required.iter().all(|name| model_dir.join(name).exists())
}

pub fn model_available(model_dir: &Path) -> bool {
    ["tokens.txt", "encoder.int8.onnx", "decoder.int8.onnx"]
        .iter()
        .all(|name| model_dir.join(name).exists())
}

impl StreamingRecognizer {
    pub fn create(model_dir: &Path, threads: i32) -> Result<Self, String> {
        let mut config = OnlineRecognizerConfig::default();
        config.model_config.tokens =
            Some(model_dir.join("tokens.txt").to_string_lossy().into_owned());
        config.model_config.paraformer.encoder = Some(
            model_dir
                .join("encoder.int8.onnx")
                .to_string_lossy()
                .into_owned(),
        );
        config.model_config.paraformer.decoder = Some(
            model_dir
                .join("decoder.int8.onnx")
                .to_string_lossy()
                .into_owned(),
        );
        config.model_config.model_type = Some("paraformer".into());
        config.model_config.num_threads = threads;
        config.decoding_method = Some("greedy_search".into());
        config.enable_endpoint = true;
        config.rule1_min_trailing_silence = 0.9;
        config.rule2_min_trailing_silence = 0.6;
        config.rule3_min_utterance_length = 20.0;
        let recognizer = OnlineRecognizer::create(&config)
            .ok_or_else(|| "无法创建 Sherpa-ONNX 流式 Paraformer 识别器".to_string())?;
        let stream = recognizer.create_stream();
        Ok(Self {
            recognizer,
            stream,
            committed: String::new(),
            last_hypothesis: String::new(),
        })
    }

    pub fn create_zipformer_ctc(model_dir: &Path, threads: i32) -> Result<Self, String> {
        let mut config = OnlineRecognizerConfig::default();
        config.model_config.tokens = Some(model_dir.join("tokens.txt").to_string_lossy().into_owned());
        config.model_config.zipformer2_ctc.model = Some(model_dir.join("model.int8.onnx").to_string_lossy().into_owned());
        config.model_config.model_type = Some("zipformer2_ctc".into());
        config.model_config.num_threads = threads;
        config.decoding_method = Some("greedy_search".into()); config.enable_endpoint = true;
        let recognizer = OnlineRecognizer::create(&config).ok_or_else(|| "无法创建流式 Zipformer CTC 识别器".to_string())?;
        let stream = recognizer.create_stream();
        Ok(Self { recognizer, stream, committed: String::new(), last_hypothesis: String::new() })
    }

    pub fn accept(&mut self, samples: &[f32]) {
        if samples.is_empty() {
            return;
        }
        self.stream.accept_waveform(16000, samples);
        self.decode_ready();
    }

    pub fn finish(mut self) -> String {
        self.stream.input_finished();
        self.decode_ready();
        self.commit_current();
        self.committed.trim().to_string()
    }

    pub fn text(&self) -> String {
        let current = self.last_hypothesis.trim();
        if current.is_empty() {
            return self.committed.trim().to_string();
        }
        if self.committed.is_empty() {
            current.to_string()
        } else {
            format!("{}{}", self.committed, current)
        }
    }

    fn decode_ready(&mut self) {
        while self.recognizer.is_ready(&self.stream) {
            self.recognizer.decode(&self.stream);
        }
        if let Some(result) = self.recognizer.get_result(&self.stream) {
            self.last_hypothesis = result.text;
        }
        if self.recognizer.is_endpoint(&self.stream) {
            self.commit_current();
            self.recognizer.reset(&self.stream);
            self.last_hypothesis.clear();
        }
    }

    fn commit_current(&mut self) {
        let current = self.last_hypothesis.trim();
        if current.is_empty() {
            return;
        }
        if self.committed.is_empty() {
            self.committed = current.to_string();
        } else if !self.committed.ends_with(current) {
            self.committed.push_str(current);
        }
        self.last_hypothesis.clear();
    }
}

/// Decode an existing recording through the same stateful streaming path used
/// for microphone capture. This keeps model comparisons fair and avoids the
/// old "streaming models cannot replay WAV" limitation.
pub fn transcribe_samples(
    model: &str,
    samples: &[f32],
    spec: &crate::audio::AudioSpec,
    resource_dir: &Path,
) -> Result<String, String> {
    let (folder, is_zipformer) = if model == "streaming_zipformer_ctc" {
        ("streaming-zipformer-ctc-zh", true)
    } else if model == "streaming_paraformer" {
        ("streaming-paraformer", false)
    } else {
        return Err("未知流式识别模型".into());
    };
    let threads = std::thread::available_parallelism()
        .map(|count| count.get().clamp(2, 6) as i32)
        .unwrap_or(4);
    let model_dir = model_dir_for(resource_dir, folder);
    let mut recognizer = if is_zipformer {
        StreamingRecognizer::create_zipformer_ctc(&model_dir, threads)?
    } else {
        StreamingRecognizer::create(&model_dir, threads)?
    };
    let channels = spec.channels.max(1) as usize;
    let mut resampler = StreamingResampler::new(spec.channels, spec.sample_rate);
    for chunk in samples.chunks(4096 * channels) {
        recognizer.accept(&resampler.push(chunk));
    }
    recognizer.accept(&resampler.finish());
    Ok(recognizer.finish())
}

pub struct StreamingResampler {
    channels: usize,
    source_rate: u32,
    buffer: Vec<f32>,
    buffer_start: usize,
    received_frames: usize,
    next_source_position: f64,
}

impl StreamingResampler {
    pub fn new(channels: u16, source_rate: u32) -> Self {
        Self {
            channels: channels.max(1) as usize,
            source_rate: source_rate.max(1),
            buffer: Vec::new(),
            buffer_start: 0,
            received_frames: 0,
            next_source_position: 0.0,
        }
    }

    pub fn push(&mut self, interleaved: &[f32]) -> Vec<f32> {
        let frames = interleaved.len() / self.channels;
        if frames == 0 {
            return Vec::new();
        }
        self.buffer.extend((0..frames).map(|frame| {
            let start = frame * self.channels;
            interleaved[start..start + self.channels]
                .iter()
                .copied()
                .sum::<f32>()
                / self.channels as f32
        }));
        self.received_frames += frames;
        self.produce(false)
    }

    pub fn finish(&mut self) -> Vec<f32> {
        self.produce(true)
    }

    fn produce(&mut self, flush: bool) -> Vec<f32> {
        let step = self.source_rate as f64 / 16000.0;
        let available_end = self.received_frames;
        let mut output = Vec::new();
        while self.next_source_position < available_end as f64
            && (flush || self.next_source_position + 1.0 < available_end as f64)
        {
            let left_index = self.next_source_position.floor() as usize;
            let right_index = (left_index + 1).min(available_end.saturating_sub(1));
            let left = self.buffer[left_index - self.buffer_start];
            let right = self.buffer[right_index - self.buffer_start];
            let weight = (self.next_source_position - left_index as f64) as f32;
            output.push(left * (1.0 - weight) + right * weight);
            self.next_source_position += step;
        }
        let keep_from = self.next_source_position.floor() as usize;
        if keep_from > self.buffer_start {
            let drop_count =
                (keep_from - self.buffer_start).min(self.buffer.len().saturating_sub(1));
            self.buffer.drain(..drop_count);
            self.buffer_start += drop_count;
        }
        output
    }
}

/* Legacy stateless helper retained for compatibility with older callers. */
pub fn downmix_resample(interleaved: &[f32], channels: u16, source_rate: u32) -> Vec<f32> {
    if interleaved.is_empty() {
        return Vec::new();
    }
    let channels = channels.max(1) as usize;
    let frames = interleaved.len() / channels;
    let mono: Vec<f32> = (0..frames)
        .map(|frame| {
            let start = frame * channels;
            interleaved[start..start + channels]
                .iter()
                .copied()
                .sum::<f32>()
                / channels as f32
        })
        .collect();
    if source_rate == 16000 {
        return mono;
    }
    let output_len = ((frames as f64) * 16000.0 / source_rate.max(1) as f64).round() as usize;
    (0..output_len)
        .map(|i| {
            let position = i as f64 * source_rate as f64 / 16000.0;
            let left = position.floor() as usize;
            let right = (left + 1).min(frames.saturating_sub(1));
            let weight = (position - left as f64) as f32;
            mono[left.min(frames - 1)] * (1.0 - weight) + mono[right] * weight
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::{transcribe_samples, StreamingResampler};
    use crate::audio;
    use std::path::PathBuf;

    #[test]
    fn stateful_resampling_is_invariant_to_chunk_boundaries() {
        let input: Vec<f32> = (0..4800)
            .map(|index| (index as f32 / 4800.0).sin())
            .collect();
        let mut one_chunk = StreamingResampler::new(1, 48000);
        let mut expected = one_chunk.push(&input);
        expected.extend(one_chunk.finish());

        let mut split = StreamingResampler::new(1, 48000);
        let mut actual = Vec::new();
        for chunk in input.chunks([37, 113, 251, 509][actual.len() % 4]) {
            actual.extend(split.push(chunk));
        }
        actual.extend(split.finish());

        assert_eq!(expected.len(), actual.len());
        for (left, right) in expected.iter().zip(actual.iter()) {
            assert!((left - right).abs() < 1e-6);
        }
    }

    #[test]
    fn streaming_zipformer_ctc_decodes_its_official_sample() {
        let root = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("resources");
        let (samples, spec) = audio::read_wav_samples(&root.join("models/streaming-zipformer-ctc-zh/test_wavs/0.wav"))
            .expect("official WAV should be readable");
        let text = transcribe_samples("streaming_zipformer_ctc", &samples, &spec, &root)
            .expect("streaming Zipformer CTC should decode its official sample");
        assert!(!text.trim().is_empty());
    }
}
