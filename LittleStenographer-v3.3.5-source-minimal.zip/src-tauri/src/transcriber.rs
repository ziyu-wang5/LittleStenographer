use std::{
    io::{Read, Write},
    net::TcpStream,
    path::{Path, PathBuf},
    process::{Child, Command},
    time::{Duration, Instant},
};

pub struct ServerProcess {
    child: Child,
    port: u16,
    model: PathBuf,
}

impl Drop for ServerProcess {
    fn drop(&mut self) {
        terminate_process_tree(&mut self.child);
    }
}

fn terminate_process_tree(child: &mut Child) {
    #[cfg(windows)]
    {
        let _ = Command::new("taskkill")
            .args(["/PID", &child.id().to_string(), "/T", "/F"])
            .output();
    }
    let _ = child.kill();
    let _ = child.wait();
}

pub fn warm_up(server: &mut Option<ServerProcess>, resource_dir: &Path) -> Result<(), String> {
    let _ = server;
    let candidates = [
        resource_dir.join("models").join("streaming-paraformer"),
        resource_dir.join("streaming-paraformer"),
        resource_dir.join("resources").join("models").join("streaming-paraformer"),
        PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("resources").join("models").join("streaming-paraformer"),
    ];
    let model_dir = candidates.iter().find(|path| {
        ["tokens.txt", "encoder.int8.onnx", "decoder.int8.onnx"]
            .iter()
            .all(|name| path.join(name).exists())
    }).cloned().unwrap_or_else(|| candidates[0].clone());
    ["tokens.txt", "encoder.int8.onnx", "decoder.int8.onnx"]
        .iter()
        .all(|name| model_dir.join(name).exists())
        .then_some(())
        .ok_or_else(|| "Streaming Paraformer 模型资源未找到".to_string())
}

pub fn transcribe(
    wav: &Path,
    language: &str,
    server: &mut Option<ServerProcess>,
    resource_dir: &Path,
) -> Result<Option<String>, String> {
    let model = locate(
        resource_dir,
        "ggml-small.bin",
        "LITTLE_STENOGRAPHER_WHISPER_MODEL",
    );
    let server_exe = locate(
        resource_dir,
        "whisper-server.exe",
        "LITTLE_STENOGRAPHER_WHISPER_SERVER",
    );
    let (Some(model), Some(server_exe)) = (model, server_exe) else {
        return Ok(None);
    };
    let lang = if language.is_empty() {
        "auto"
    } else {
        language
    };

    ensure_server(server, &server_exe, &model, resource_dir)?;
    let port = server
        .as_ref()
        .map(|process| process.port)
        .ok_or_else(|| "Whisper server is unavailable".to_string())?;
    let bytes = std::fs::read(wav).map_err(|e| format!("Could not read WAV: {e}"))?;
    let text = request_server(port, &bytes, lang, "", 0, 0, true)?;
    Ok((!text.trim().is_empty()).then_some(text.trim().to_string()))
}

pub fn transcribe_segment(
    wav: &Path,
    language: &str,
    prompt: &str,
    offset_ms: u32,
    duration_ms: u32,
    reset_context: bool,
    server: &mut Option<ServerProcess>,
    resource_dir: &Path,
) -> Result<Option<String>, String> {
    let model = locate(
        resource_dir,
        "ggml-small.bin",
        "LITTLE_STENOGRAPHER_WHISPER_MODEL",
    );
    let server_exe = locate(
        resource_dir,
        "whisper-server.exe",
        "LITTLE_STENOGRAPHER_WHISPER_SERVER",
    );
    let (Some(model), Some(server_exe)) = (model, server_exe) else {
        return Ok(None);
    };
    ensure_server(server, &server_exe, &model, resource_dir)?;
    let port = server
        .as_ref()
        .map(|process| process.port)
        .ok_or_else(|| "Whisper server is unavailable".to_string())?;
    let bytes = std::fs::read(wav).map_err(|e| format!("Could not read WAV: {e}"))?;
    let lang = if language.is_empty() {
        "auto"
    } else {
        language
    };
    let text = request_server(
        port,
        &bytes,
        lang,
        prompt,
        offset_ms,
        duration_ms,
        reset_context,
    )?;
    Ok((!text.trim().is_empty()).then_some(text.trim().to_string()))
}

fn ensure_server(
    server: &mut Option<ServerProcess>,
    executable: &Path,
    model: &Path,
    resource_dir: &Path,
) -> Result<(), String> {
    const PORT: u16 = 38123;
    if server.as_ref().is_some_and(|process| {
        process.model == model && TcpStream::connect(("127.0.0.1", process.port)).is_ok()
    }) {
        return Ok(());
    }
    *server = None;
    let threads = std::thread::available_parallelism()
        .map(|count| count.get().clamp(2, 8).to_string())
        .unwrap_or_else(|_| "4".to_string());
    let mut child = Command::new(executable)
        .current_dir(resource_dir)
        .args([
            "-m",
            model.to_string_lossy().as_ref(),
            "--host",
            "127.0.0.1",
            "--port",
            &PORT.to_string(),
            "-ng",
            "-nt",
            "-t",
            &threads,
            "-bo",
            "2",
            "-l",
            "auto",
        ])
        .spawn()
        .map_err(|e| format!("Could not start Whisper server: {e}"))?;
    let deadline = Instant::now() + Duration::from_secs(120);
    while Instant::now() < deadline {
        if TcpStream::connect(("127.0.0.1", PORT)).is_ok() {
            *server = Some(ServerProcess {
                child,
                port: PORT,
                model: model.to_path_buf(),
            });
            return Ok(());
        }
        if child.try_wait().map_err(|e| e.to_string())?.is_some() {
            break;
        }
        std::thread::sleep(Duration::from_millis(200));
    }
    terminate_process_tree(&mut child);
    Err("Whisper server did not become ready".to_string())
}

fn request_server(
    port: u16,
    wav: &[u8],
    language: &str,
    prompt: &str,
    offset_ms: u32,
    duration_ms: u32,
    reset_context: bool,
) -> Result<String, String> {
    let boundary = "little-stenographer-boundary";
    let mut body = Vec::with_capacity(wav.len() + 512);
    add_field(&mut body, boundary, "response_format", "text");
    add_field(&mut body, boundary, "language", language);
    add_field(
        &mut body,
        boundary,
        "no_context",
        if reset_context { "true" } else { "false" },
    );
    if !prompt.is_empty() {
        add_field(&mut body, boundary, "prompt", prompt);
    }
    if offset_ms > 0 {
        add_field(&mut body, boundary, "offset_t", &offset_ms.to_string());
    }
    if duration_ms > 0 {
        add_field(&mut body, boundary, "duration", &duration_ms.to_string());
    }
    body.extend_from_slice(format!("--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"recording.wav\"\r\nContent-Type: audio/wav\r\n\r\n").as_bytes());
    body.extend_from_slice(wav);
    body.extend_from_slice(format!("\r\n--{boundary}--\r\n").as_bytes());
    let mut stream = TcpStream::connect(("127.0.0.1", port))
        .map_err(|e| format!("Could not connect to Whisper server: {e}"))?;
    stream
        .set_read_timeout(Some(Duration::from_secs(300)))
        .map_err(|e| e.to_string())?;
    write!(stream, "POST /inference HTTP/1.1\r\nHost: 127.0.0.1:{port}\r\nContent-Type: multipart/form-data; boundary={boundary}\r\nContent-Length: {}\r\nConnection: close\r\n\r\n", body.len()).map_err(|e| e.to_string())?;
    stream.write_all(&body).map_err(|e| e.to_string())?;
    let mut response = Vec::new();
    stream
        .read_to_end(&mut response)
        .map_err(|e| format!("Whisper server response failed: {e}"))?;
    let response = String::from_utf8_lossy(&response);
    let (headers, content) = response
        .split_once("\r\n\r\n")
        .ok_or_else(|| "Invalid Whisper server response".to_string())?;
    if !headers.starts_with("HTTP/1.1 200") {
        return Err(format!("Whisper server error: {content}"));
    }
    Ok(content.trim().to_string())
}

fn add_field(body: &mut Vec<u8>, boundary: &str, name: &str, value: &str) {
    body.extend_from_slice(
        format!(
            "--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"\r\n\r\n{value}\r\n"
        )
        .as_bytes(),
    );
}

fn locate(resource_dir: &Path, filename: &str, env_name: &str) -> Option<PathBuf> {
    if let Ok(value) = std::env::var(env_name) {
        let path = PathBuf::from(value);
        if path.exists() {
            return Some(path);
        }
    }
    for path in [
        resource_dir.join(filename),
        resource_dir.join("models").join(filename),
        resource_dir.join("engine").join(filename),
    ] {
        if path.exists() {
            return Some(path);
        }
    }
    let dev_path = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("resources")
        .join(if filename.ends_with(".exe") {
            "engine"
        } else {
            "models"
        })
        .join(filename);
    dev_path.exists().then_some(dev_path)
}
