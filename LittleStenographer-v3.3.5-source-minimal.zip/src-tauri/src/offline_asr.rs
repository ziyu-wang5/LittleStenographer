use crate::audio::AudioSpec;
use sherpa_onnx::{
    OfflineQwen3ASRModelConfig, OfflineRecognizer, OfflineRecognizerConfig, OfflineSenseVoiceModelConfig,
};
use std::path::{Path, PathBuf};

pub const ZIPFORMER_CTC: &str = "zipformer_ctc";
pub const SENSEVOICE: &str = "sensevoice";
pub const QWEN3_ASR: &str = "qwen3_asr";

pub fn label(model: &str) -> &'static str {
    match model {
        ZIPFORMER_CTC => "Zipformer CTC 中文 int8（精准）",
        SENSEVOICE => "SenseVoiceSmall int8（精准 + 标点）",
        QWEN3_ASR => "Qwen3-ASR 0.6B int8（高准确）",
        _ => "Streaming Paraformer int8（极速）",
    }
}

pub fn is_offline_model(model: &str) -> bool {
    matches!(model, ZIPFORMER_CTC | SENSEVOICE | QWEN3_ASR)
}

pub struct SenseVoiceRecognizer {
    recognizer: OfflineRecognizer,
}

impl SenseVoiceRecognizer {
    pub fn create(language: &str, resource_dir: &Path) -> Result<Self, String> {
        let model_file = locate_model(resource_dir, "sensevoice", "model.int8.onnx")
            .ok_or_else(|| "SenseVoice 测试模型未找到".to_string())?;
        let tokens_file = locate_model(resource_dir, "sensevoice", "tokens.txt")
            .ok_or_else(|| "SenseVoice tokens 未找到".to_string())?;
        let language = match language {
            "zh" | "en" => language,
            _ => "auto",
        };
        let mut config = OfflineRecognizerConfig::default();
        config.model_config.tokens = Some(tokens_file.to_string_lossy().into_owned());
        config.model_config.num_threads = std::thread::available_parallelism()
            .map(|count| count.get().clamp(2, 8) as i32)
            .unwrap_or(4);
        config.model_config.sense_voice = OfflineSenseVoiceModelConfig {
            model: Some(model_file.to_string_lossy().into_owned()),
            language: Some(language.into()),
            use_itn: true,
        };
        let recognizer = OfflineRecognizer::create(&config)
            .ok_or_else(|| "无法加载 SenseVoiceSmall int8（精准 + 标点）".to_string())?;
        Ok(Self { recognizer })
    }

    pub fn transcribe(&self, samples: &[f32], spec: &AudioSpec) -> Option<String> {
        if samples.is_empty() {
            return None;
        }
        let mono_samples = downmix(samples, spec.channels);
        let stream = self.recognizer.create_stream();
        stream.accept_waveform(spec.sample_rate as i32, &mono_samples);
        self.recognizer.decode(&stream);
        stream.get_result().map(|result| result.text.trim().to_string()).filter(|text| !text.is_empty())
    }

    pub fn transcribe_16k(&self, samples: &[f32]) -> Option<String> {
        self.transcribe(samples, &AudioSpec { sample_rate: 16_000, channels: 1 })
    }
}

pub fn transcribe(
    model: &str,
    samples: &[f32],
    spec: &AudioSpec,
    language: &str,
    resource_dir: &Path,
) -> Result<String, String> {
    let (model_file, tokens_file) = match model {
        ZIPFORMER_CTC => locate_model(resource_dir, "zipformer-ctc-zh", "model.int8.onnx")
            .zip(locate_model(resource_dir, "zipformer-ctc-zh", "tokens.txt"))
            .ok_or_else(|| "Zipformer CTC 测试模型未找到".to_string())?,
        SENSEVOICE => locate_model(resource_dir, "sensevoice", "model.int8.onnx")
            .zip(locate_model(resource_dir, "sensevoice", "tokens.txt"))
            .ok_or_else(|| "SenseVoice 测试模型未找到".to_string())?,
        QWEN3_ASR => {
            let folder = locate_qwen3_model_dir(resource_dir)
                .ok_or_else(|| "Qwen3-ASR 模型文件不完整（需要 ONNX 与 tokenizer 目录）".to_string())?;
            (folder.join("decoder.int8.onnx"), PathBuf::new())
        }
        _ => return Err("未知离线识别模型".into()),
    };
    let mut config = OfflineRecognizerConfig::default();
    if !tokens_file.as_os_str().is_empty() {
        config.model_config.tokens = Some(tokens_file.to_string_lossy().into_owned());
    }
    config.model_config.num_threads = if model == QWEN3_ASR {
        // Qwen's decoder is large. A conservative thread count avoids a burst
        // of per-thread allocator pressure when it is initialized in a GUI app.
        2
    } else {
        std::thread::available_parallelism()
        .map(|count| count.get().clamp(2, 8) as i32)
        .unwrap_or(4)
    };
    match model {
        ZIPFORMER_CTC => {
            config.model_config.zipformer_ctc.model =
                Some(model_file.to_string_lossy().into_owned());
            config.model_config.model_type = Some("zipformer_ctc".into());
        }
        SENSEVOICE => {
            let language = match language {
                "zh" | "en" => language,
                _ => "auto",
            };
            config.model_config.sense_voice = OfflineSenseVoiceModelConfig {
                model: Some(model_file.to_string_lossy().into_owned()),
                language: Some(language.into()),
                use_itn: true,
            };
        }
        QWEN3_ASR => {
            let folder = model_file.parent().ok_or_else(|| "Qwen3-ASR 目录无效".to_string())?;
            config.model_config.qwen3_asr = OfflineQwen3ASRModelConfig {
                conv_frontend: Some(folder.join("conv_frontend.onnx").to_string_lossy().into_owned()),
                encoder: Some(folder.join("encoder.int8.onnx").to_string_lossy().into_owned()),
                decoder: Some(model_file.to_string_lossy().into_owned()),
                tokenizer: Some(folder.join("tokenizer").to_string_lossy().into_owned()),
                ..Default::default()
            };
        }
        _ => unreachable!(),
    }
    let mono_samples = downmix(samples, spec.channels);
    let recognizer = OfflineRecognizer::create(&config).ok_or_else(|| {
        format!(
            "无法加载 {}。已确认模型文件存在；请关闭其他占内存较大的程序后重试。Qwen3-ASR 首次加载约需 1–2 GB 可用内存。",
            label(model)
        )
    })?;
    let stream = recognizer.create_stream();
    stream.accept_waveform(spec.sample_rate as i32, &mono_samples);
    recognizer.decode(&stream);
    stream
        .get_result()
        .map(|result| result.text.trim().to_string())
        .filter(|text| !text.is_empty())
        .ok_or_else(|| "离线模型没有返回识别结果".into())
}

fn downmix(samples: &[f32], channels: u16) -> Vec<f32> {
    let channels = channels.max(1) as usize;
    if channels == 1 {
        return samples.to_vec();
    }
    samples
        .chunks_exact(channels)
        .map(|frame| frame.iter().sum::<f32>() / channels as f32)
        .collect()
}

fn locate_model(resource_dir: &Path, folder: &str, filename: &str) -> Option<PathBuf> {
    [
        resource_dir.join("models").join(folder).join(filename),
        resource_dir.join(folder).join(filename),
        resource_dir.join("resources").join("models").join(folder).join(filename),
        PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("resources")
            .join("models")
            .join(folder)
            .join(filename),
    ]
    .into_iter()
    .find(|path| path.exists())
}

fn locate_qwen3_model_dir(resource_dir: &Path) -> Option<PathBuf> {
    [
        resource_dir.join("models/qwen3-asr-0.6b"),
        resource_dir.join("qwen3-asr-0.6b"),
        resource_dir.join("resources/models/qwen3-asr-0.6b"),
        PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("resources/models/qwen3-asr-0.6b"),
    ]
    .into_iter()
    .find(|folder| {
        ["conv_frontend.onnx", "encoder.int8.onnx", "decoder.int8.onnx", "tokenizer/vocab.json", "tokenizer/merges.txt"]
            .iter()
            .all(|file| folder.join(file).is_file())
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use sherpa_onnx::Wave;

    fn decode_official_sample(model: &str, sample: &str) {
        let root = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("resources");
        let wave = Wave::read(sample).expect("official test WAV should be readable");
        let text = transcribe(
            model,
            wave.samples(),
            &AudioSpec {
                sample_rate: wave.sample_rate() as u32,
                channels: 1,
            },
            "zh",
            &root,
        )
        .expect("model should transcribe its official test WAV");
        assert!(!text.trim().is_empty());
    }

    #[test]
    fn zipformer_ctc_decodes_official_sample() {
        decode_official_sample(
            ZIPFORMER_CTC,
            concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/resources/models/zipformer-ctc-zh/test_wavs/0.wav"
            ),
        );
    }

    #[test]
    fn sensevoice_decodes_official_sample() {
        decode_official_sample(
            SENSEVOICE,
            concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/resources/models/sensevoice/test_wavs/zh.wav"
            ),
        );
    }

    #[test]
    fn qwen3_asr_decodes_official_sample() {
        decode_official_sample(
            QWEN3_ASR,
            concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/resources/models/qwen3-asr-0.6b/test_wavs/raokouling.wav"
            ),
        );
    }

    #[test]
    fn qwen3_asr_decodes_from_tauri_resource_copy() {
        let source_root = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("resources");
        let resource_root = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("target/debug/resources");
        let sample = source_root.join("models/qwen3-asr-0.6b/test_wavs/raokouling.wav");
        let wave = Wave::read(&sample.to_string_lossy())
            .expect("official test WAV should be readable");
        let text = transcribe(
            QWEN3_ASR,
            wave.samples(),
            &AudioSpec { sample_rate: wave.sample_rate() as u32, channels: 1 },
            "zh",
            &resource_root,
        )
        .expect("Qwen3-ASR should decode with Tauri's copied resource directory");
        assert!(!text.trim().is_empty());
    }
}
