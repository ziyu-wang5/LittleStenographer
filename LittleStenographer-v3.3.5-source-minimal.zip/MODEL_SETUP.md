# SenseVoiceSmall model setup / SenseVoiceSmall 模型准备

The release installer includes the required SenseVoiceSmall model files. This guide is only for building the minimal source package yourself.

正式安装包已包含 SenseVoiceSmall 模型文件。本说明仅适用于自行构建最小源码包。

## Required files / 所需文件

Place the following files in `src-tauri/resources/models/sensevoice/`:

```text
model.int8.onnx
tokens.txt
```

Keep the accompanying upstream model license in the same directory as `LICENSE`.

请同时将上游模型许可证以 `LICENSE` 文件保留在该目录中。

## Build / 构建

After the files are in place:

```powershell
npm install
npm run tauri -- build
```

The model weights are governed by their own license and are not covered by this repository's MIT license. See `LICENSES/THIRD_PARTY_NOTICES.md`.

模型权重受其自身许可证约束，不属于本仓库 MIT 许可证的覆盖范围。详见 `LICENSES/THIRD_PARTY_NOTICES.md`。
