import { useEffect, useState } from "react";
import { invoke } from "@tauri-apps/api/core";
import { emit, listen } from "@tauri-apps/api/event";
import { open } from "@tauri-apps/plugin-dialog";
import "./layout.css";
import "./prompt-debug.css";

type AppSettings = { hotkey: string; language: string; asrModel: string; launchOnStartup: boolean; cloudEnabled: boolean; cloudBaseUrl: string; cloudModel: string; llmPrompt: string; savedLlmPrompt: string; localLlmEnabled: boolean; senseVoiceVadStreaming: boolean };
type HistoryItem = { id: number; text: string; time: string };
type TranscriptionResult = { text: string; rawText: string };
type RuntimeStatus = { version: string; phase: string; whisperReady: boolean; llmReady: boolean; whisperModel: string; llmModel: string; lastError?: string | null };

const defaultSettings: AppSettings = { hotkey: "Alt+Space", language: "auto", asrModel: "sensevoice", launchOnStartup: false, cloudEnabled: false, cloudBaseUrl: "https://api.openai.com/v1", cloudModel: "gpt-5.6-luna", llmPrompt: "", savedLlmPrompt: "", localLlmEnabled: false, senseVoiceVadStreaming: false };
const APP_VERSION = "v3.3.5";

function StatusOverlay() {
  const [phase, setPhase] = useState("录音中");
  useEffect(() => {
    let remove: (() => void) | undefined;
    // Rust also calls this function directly: the transparent overlay is a
    // separate WebView and may otherwise miss an event while waking up.
    (window as Window & { __setOverlayStatus?: (next: string) => void }).__setOverlayStatus = setPhase;
    listen<string>("overlay-status", ({ payload }) => setPhase(payload)).then((unlisten) => { remove = unlisten; });
    return () => { remove?.(); delete (window as Window & { __setOverlayStatus?: (next: string) => void }).__setOverlayStatus; };
  }, []);
  const listening = phase === "录音中";
  return <div className={`cursor-overlay ${listening ? "listening-mode" : "recognizing-mode"}`}><span className={`cursor-orbit ${listening ? "listening" : "thinking"}`}>✦</span><span>{listening ? "正在聆听" : "正在识别，请稍后"}</span></div>;
}

function App() {
  const [recording, setRecording] = useState(false);
  const [settings, setSettings] = useState<AppSettings>(defaultSettings);
  const [hotkeyDraft, setHotkeyDraft] = useState(defaultSettings.hotkey);
  const [message, setMessage] = useState("准备就绪");
  const [lastText, setLastText] = useState("按住快捷键，说出你想输入的内容");
  const [rawText, setRawText] = useState("");
  const [promptDraft, setPromptDraft] = useState("");
  const [promptTest, setPromptTest] = useState("");
  const [promptBusy, setPromptBusy] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [runtime, setRuntime] = useState<RuntimeStatus>({ version: APP_VERSION, phase: "启动中", whisperReady: false, llmReady: false, whisperModel: "Streaming Paraformer int8", llmModel: "Qwen3 1.7B Q4_K_M" });
  const [apiKey, setApiKey] = useState("");
  const [apiKeySet, setApiKeySet] = useState(false);
  const [trayHiding, setTrayHiding] = useState(false);

  const copyCurrent = async () => { await invoke("copy_text", { text: lastText }); setMessage("已复制到剪贴板"); };
  const finishResult = async (encoded: string) => {
    if (!encoded) return;
    let result: TranscriptionResult;
    try { result = JSON.parse(encoded) as TranscriptionResult; } catch { result = { text: encoded, rawText: encoded }; }
    if (!result.text) return;
    let pasted = false;
    try { await invoke("paste_text", { text: result.text }); pasted = true; }
    catch { await invoke("copy_text", { text: result.text }).catch(() => undefined); }
    await invoke("finish_transcription").catch(() => undefined);
    setLastText(result.text);
    setRawText(result.rawText || result.text);
    setHistory((items) => [{ id: Date.now(), text: result.text, time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) }, ...items].slice(0, 12));
    setMessage(pasted ? "已粘贴到当前光标" : "已复制到剪贴板，可手动粘贴");
  };

  useEffect(() => {
    void emit("main-ui-ready").catch(() => undefined);
    invoke<AppSettings>("get_settings").then((saved) => { const next = { ...defaultSettings, ...saved }; setSettings(next); setHotkeyDraft(next.hotkey); setPromptDraft(next.llmPrompt); }).catch(() => undefined);
    invoke<boolean>("has_cloud_api_key").then(setApiKeySet).catch(() => undefined);
    const refreshRuntime = () => { invoke<RuntimeStatus>("get_runtime_status").then(setRuntime).catch(() => undefined); };
    refreshRuntime();
    const runtimeTimer = window.setInterval(refreshRuntime, 800);
    let unlisten: (() => void) | undefined;
    let unlistenTrayHide: (() => void) | undefined;
    let unlistenTrayShow: (() => void) | undefined;
    listen("main-tray-hide", () => setTrayHiding(true)).then((remove) => { unlistenTrayHide = remove; }).catch(() => undefined);
    listen("main-tray-show", () => setTrayHiding(false)).then((remove) => { unlistenTrayShow = remove; }).catch(() => undefined);
    listen<boolean>("shortcut-recording", async ({ payload }) => {
      setRecording(payload); setMessage(payload ? "正在聆听…" : "正在整理文本…");
      if (payload) { setLastText(""); setRawText(""); }
      if (payload) await invoke("start_recording", { fromUi: false }).catch((error) => setMessage(`录音启动失败：${String(error)}`));
      else {
        // The main window has definitely received this release event, so also
        // confirm the visual state directly before recognition starts.
        void invoke("show_recognizing_overlay").catch(() => undefined);
        await finishResult(await invoke<string>("stop_recording").catch(() => ""));
      }
    }).then((remove) => { unlisten = remove; }).catch(() => undefined);
    return () => { unlisten?.(); unlistenTrayHide?.(); unlistenTrayShow?.(); window.clearInterval(runtimeTimer); };
  }, []);

  const toggleRecording = async () => {
    try {
      const next = !recording;
      if (next) {
        setMessage("正在启动麦克风…");
        const result = await invoke<string>("start_recording", { fromUi: true });
        if (result !== "recording" && result !== "already-recording") {
          setRecording(false);
          setMessage(`录音未启动：${result}`);
          return;
        }
        setRecording(true);
        setLastText("");
        setRawText("");
        setMessage("正在聆听…");
      } else {
        setRecording(false);
        setMessage("正在整理文本…");
        await finishResult(await invoke<string>("stop_recording"));
      }
    }
    catch (error) { setRecording(false); setMessage(`暂不可用：${String(error)}`); }
  };
  const updateSettings = async (patch: Partial<AppSettings>) => { const next = { ...settings, ...patch }; setSettings(next); await invoke("save_settings", { settings: next }).catch((error) => setMessage(`设置保存失败：${String(error)}`)); };
  const selectAsrModel = async (asrModel: string, label: string) => { await updateSettings({ asrModel }); setRuntime((current) => ({ ...current, whisperModel: label, phase: "已选择，等待复测" })); setMessage(`已选择 ${label}。现在点击“选择录音文件复测”即可开始比较。`); };
  const saveHotkey = async () => { const value = hotkeyDraft.trim() || "Ctrl+Space"; await updateSettings({ hotkey: value }); setHotkeyDraft(value); setMessage(`快捷键已设置为 ${value}`); };
  const saveApiKey = async () => { if (!apiKey.trim()) return; await invoke("save_cloud_api_key", { key: apiKey.trim() }); setApiKey(""); setApiKeySet(true); setMessage("云端 API Key 已保存"); };
  const selectRecordingForTest = async () => {
    try {
      setMessage("正在打开 WAV 文件选择窗口…");
      const defaultPath = await invoke<string>("recordings_directory");
      const selected = await open({ defaultPath, multiple: false, filters: [{ name: "WAV 录音", extensions: ["wav"] }] });
      if (typeof selected !== "string") return;
      setMessage("正在使用选中的录音复测…");
      await finishResult(await invoke<string>("transcribe_selected_recording", { path: selected }));
    } catch (error) { console.error("打开录音文件失败", error); setMessage(`录音复测失败：${String(error)}`); }
  };

  const testPrompt = async () => { const source = rawText || lastText; if (!source.trim()) { setMessage("请先录音或填写原始文本"); return; } setPromptBusy(true); setMessage("正在测试提示词…"); try { const result = await invoke<string>("test_llm_prompt", { prompt: promptDraft, text: source }); setPromptTest(result); setLastText(result); setMessage("提示词测试完成，结果已显示在最近一次输出"); } catch (error) { setMessage(`提示词测试失败：${String(error)}`); } finally { setPromptBusy(false); } };
  const resetPrompt = async () => { const value = await invoke<string>("reset_default_llm_prompt"); setPromptDraft(value); setSettings((current) => ({ ...current, llmPrompt: value })); setMessage("已恢复默认提示词"); };
  const savePrompt = async () => { const value = await invoke<string>("save_user_llm_prompt", { prompt: promptDraft }); setSettings((current) => ({ ...current, llmPrompt: value, savedLlmPrompt: value })); setMessage("已保存为用户提示词"); };
  const restorePrompt = async () => { const value = await invoke<string>("restore_user_llm_prompt"); setPromptDraft(value); setSettings((current) => ({ ...current, llmPrompt: value })); setMessage("已恢复上次保存的用户提示词"); };
  return <main className={`shell ${trayHiding ? "tray-hiding" : ""}`}>
    <header className="topbar"><div className="brand"><span className="brand-mark">✦</span><span>Little Stenographer</span><span className="version-badge">{APP_VERSION}</span></div><span className="offline"><i /> 离线模式</span></header>
    <section className="hero"><div className="eyebrow">VOICE TO TEXT / LOCAL FIRST</div><h1>把想法直接说出来。</h1><p className="subtitle">中英文语音识别，自动整理并插入当前光标。</p><button className={`record-button ${recording ? "is-recording" : ""}`} onClick={toggleRecording} aria-label={recording ? "停止录音" : "开始录音"}><span className="mic">{recording ? "■" : "●"}</span><span>{recording ? "结束录音" : "开始录音"}</span><kbd>{settings.hotkey}</kbd></button><div className={`status ${recording ? "active" : ""}`}><span className="pulse" />{message}</div></section>
    <section className="output-layout">
      <section className="card history-card"><div className="card-heading"><span>历史记录</span><span className="muted">点击恢复</span></div><div className="history-list">{history.length ? history.map((item) => <button className="history-item" key={item.id} onClick={() => setLastText(item.text)}><span>{item.text}</span><small>{item.time}</small></button>) : <div className="history-empty">暂无历史记录</div>}</div></section>
      <section className="card transcript-card"><div className="card-heading"><span>最近一次输出</span><div className="output-actions"><button className="copy-button" onClick={copyCurrent}>复制</button></div></div><textarea className="transcript-editor" value={lastText} onChange={(e) => setLastText(e.target.value)} /></section>
    </section>
    <section className="card quick-settings"><div className="card-heading"><span>SenseVoice</span><span className={runtime.whisperReady ? "ready" : "muted"}>{runtime.whisperReady ? "本地引擎就绪" : "启动中"}</span></div><div className="engine-row"><span>当前引擎</span><span className="value">SenseVoiceSmall · 标点与数字规范化</span></div><div className="engine-row"><span>识别语言</span><select value={settings.language} onChange={(e) => updateSettings({ language: e.target.value })}><option value="auto">自动识别（中英）</option><option value="zh">中文优先</option><option value="en">English first</option></select></div><div className="engine-row shortcut-setting"><span>全局快捷键</span><input value={hotkeyDraft} onChange={(e) => setHotkeyDraft(e.target.value)} onBlur={saveHotkey} onKeyDown={(e) => { if (e.key === "Enter") e.currentTarget.blur(); }} placeholder="Alt+Space" /></div><button className="copy-button" onClick={selectRecordingForTest}>选择录音文件复测</button><small className="muted">按住 Alt+Space 录音，松开即完成识别并粘贴。</small></section>
    <footer><span>所有内容仅保存在本机</span><span>SenseVoice · 本地语音识别</span></footer>
  </main>;
}
export default new URLSearchParams(window.location.search).has("overlay") ? StatusOverlay : App;
