# Little Stenographer 第三方许可证声明

本文件随 Windows 安装包发布。项目自身代码的许可证见安装目录中的 `LICENSE`。

## Tauri、React 与构建组件

本应用使用 Tauri、React、Vite、TypeScript 及其依赖。相关组件分别采用 MIT、Apache-2.0、BSD、ISC 等许可证。完整依赖版本锁定在源码发布包中的 `package-lock.json` 与 `src-tauri/Cargo.lock`；各依赖的许可证和版权声明以其上游发行包为准。

## Rust 与原生运行库

本应用使用 `tauri`、`tauri-plugin-dialog`、`tauri-plugin-global-shortcut`、`cpal`、`hound`、`reqwest`、`windows-sys`、`sherpa-onnx` 及其传递依赖。它们的许可证、版权和适用的通知义务以本次构建所锁定版本的上游发行包为准。

## SenseVoiceSmall 模型

本安装包包含 SenseVoiceSmall 语音识别模型。该预训练模型不属于本项目的 MIT 许可证；模型的授权、署名、再分发和商业使用条件由模型提供方单独规定。模型随附的许可证文件位于：

`resources/models/sensevoice/LICENSE`

使用或再分发该模型前，请核对其模型卡、上游仓库以及上述许可证要求。不得仅因本项目代码采用 MIT 许可证而推断模型权重可在任何场景下自由使用。

## 发布说明

本文件是第三方声明汇总，不替代任何第三方组件的完整许可证文本。面向公开发行、商用或合规审计时，发布者应基于锁定依赖生成并审阅完整 SBOM 与许可证清单。
