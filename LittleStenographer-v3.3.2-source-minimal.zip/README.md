# Little Stenographer Minimal

面向 Windows 的最小离线中英文语音输入应用。最终发布版只包含：麦克风录音、`Alt+Space` 全局快捷键、SenseVoiceSmall 本地识别、剪贴板复制、WAV 复测和本地历史记录。

## 开发

```powershell
npm install
npm run tauri:dev
```

## 模型安装

本仓库不再提交模型权重。请阅读 [MODEL_SETUP.md](MODEL_SETUP.md)，从原始模型发布页获取 `model.int8.onnx` 和 `tokens.txt`，放到 `src-tauri/resources/models/sensevoice/` 后再构建。

## 许可证

本项目新增源码采用 MIT，详见 [LICENSE](LICENSE)。第三方软件和模型的授权不被本项目许可证覆盖，详见 [LICENSES/THIRD_PARTY_NOTICES.md](LICENSES/THIRD_PARTY_NOTICES.md)。发布安装包时必须同时随附这些声明。

本项目只保证“本项目新增源码”采用 MIT；模型权重、测试音频、第三方库和运行时各自受其原始许可证约束。
