# Third-party notices

## Tauri

`tauri`、`@tauri-apps/api`、`@tauri-apps/plugin-dialog`、`tauri-plugin-global-shortcut` 及其依赖包含 MIT、Apache-2.0、BSD、ISC 等许可证的组件。发布时请保留由 `npm` 和 Cargo 生成的依赖清单及各包许可证文本；依赖版本分别记录在 `package-lock.json` 与 `src-tauri/Cargo.lock`。

## sherpa-onnx

本项目通过 `sherpa-onnx` 调用本地 ONNX 识别模型。请随发布包保留该项目及其所带原生运行库的版权和许可证声明，并以实际构建版本的发行包为准。

## SenseVoiceSmall

SenseVoiceSmall 是第三方预训练模型，不属于本项目 MIT 许可证。FunASR 官方说明：工具包源码采用 MIT，而预训练权重按各模型卡或 FunASR Model Open Source License Agreement 单独授权。使用和商业分发前必须遵守模型卡、署名、模型名称保留及再分发要求。

## Model source and test data

模型权重、转换脚本、示例音频和 tokenizer 可能由不同主体提供，不能仅因代码仓库开源就推断它们可商业再分发。最小版默认不包含这些文件，发布者应自行完成逐项核查。

## Compliance note

这是项目的开源声明，不是对第三方模型或依赖许可证的替代。发布二进制安装包前，应生成并审查完整 SBOM/依赖许可证清单，并把本文件与 `LICENSE` 一起放入源码仓库和安装包的“关于/许可证”目录。
