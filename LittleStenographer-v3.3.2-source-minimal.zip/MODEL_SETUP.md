# SenseVoiceSmall 模型安装

最小版不会把模型权重提交到代码仓库，也不会替用户重新分发模型。请从官方模型页获取与当前 `sherpa-onnx` 转换格式匹配的文件：

- 来源说明：[FunASR / SenseVoice](https://github.com/modelscope/FunASR)
- 模型卡：[FunAudioLLM/SenseVoiceSmall](https://huggingface.co/FunAudioLLM/SenseVoiceSmall)
- 需要文件：`model.int8.onnx`、`tokens.txt`
- 放置目录：`src-tauri/resources/models/sensevoice/`

使用前请阅读模型卡和 FunASR 的模型许可证。不要把未确认授权的权重、测试音频或转换产物重新打包到公共发布包中。
