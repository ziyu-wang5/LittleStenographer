use cpal::traits::{DeviceTrait, HostTrait, StreamTrait};
use cpal::{SampleFormat, StreamConfig};
use std::{sync::{mpsc, Arc, Mutex}, time::Duration};
use std::thread::JoinHandle;

pub struct RecordingHandle {
    pub samples: Arc<Mutex<Vec<f32>>>,
    pub spec: AudioSpec,
    stop_sender: mpsc::Sender<()>,
    worker: Option<JoinHandle<Result<AudioSpec, String>>>,
}

#[derive(Clone)]
pub struct AudioSpec {
    pub sample_rate: u32,
    pub channels: u16,
}

pub fn start() -> Result<RecordingHandle, String> {
    let host = cpal::default_host();
    let device = host
        .default_input_device()
        .ok_or("No default microphone was found")?;
    let supported = device
        .default_input_config()
        .map_err(|e| format!("Could not read microphone config: {e}"))?;
    let spec = AudioSpec {
        sample_rate: supported.sample_rate().0,
        channels: supported.channels(),
    };
    let samples = Arc::new(Mutex::new(Vec::<f32>::new()));
    let worker_samples = Arc::clone(&samples);
    let (stop_sender, stop_receiver) = mpsc::channel();
    let (ready_sender, ready_receiver) = mpsc::sync_channel(1);
    let worker = std::thread::Builder::new()
        .name("audio-capture".into())
        .spawn(move || {
            let result = (|| -> Result<AudioSpec, String> {
                let host = cpal::default_host();
                let device = host
                    .default_input_device()
                    .ok_or("No default microphone was found")?;
                let supported = device
                    .default_input_config()
                    .map_err(|e| format!("Could not read microphone config: {e}"))?;
                let sample_format = supported.sample_format();
                let config: StreamConfig = supported.into();
                let spec = AudioSpec { sample_rate: config.sample_rate.0, channels: config.channels };
                let buffer = Arc::clone(&worker_samples);
                let on_error = |error| eprintln!("audio input error: {error}");
                let stream = match sample_format {
                    SampleFormat::F32 => device.build_input_stream(&config, move |data: &[f32], _| push_f32(data, &buffer), on_error, None),
                    SampleFormat::I16 => device.build_input_stream(&config, move |data: &[i16], _| push_i16(data, &buffer), on_error, None),
                    SampleFormat::U16 => device.build_input_stream(&config, move |data: &[u16], _| push_u16(data, &buffer), on_error, None),
                    format => return Err(format!("Unsupported microphone sample format: {format:?}")),
                }.map_err(|e| format!("Could not create recording stream: {e}"))?;
                stream.play().map_err(|e| format!("Could not start microphone: {e}"))?;
                let _ = ready_sender.send(Ok(()));
                let _ = stop_receiver.recv();
                drop(stream);
                Ok(spec)
            })();
            if let Err(error) = &result {
                let _ = ready_sender.send(Err(error.clone()));
            }
            result
        })
        .map_err(|e| format!("Could not create audio thread: {e}"))?;
    match ready_receiver.recv_timeout(Duration::from_secs(2)) {
        Ok(Ok(())) => {}
        Ok(Err(error)) => return Err(error),
        Err(_) => return Err("麦克风启动超时".into()),
    }
    Ok(RecordingHandle {
        samples,
        spec,
        stop_sender,
        worker: Some(worker),
    })
}

pub fn stop(mut handle: RecordingHandle) -> Result<(Arc<Mutex<Vec<f32>>>, AudioSpec), String> {
    let _ = handle.stop_sender.send(());
    let _ = handle
        .worker
        .take()
        .ok_or("Audio thread is unavailable")?
        .join()
        .map_err(|_| "Audio thread stopped unexpectedly".to_string())??;
    Ok((handle.samples, handle.spec))
}

fn push_f32(data: &[f32], target: &Arc<Mutex<Vec<f32>>>) {
    if let Ok(mut buffer) = target.lock() {
        buffer.extend_from_slice(data);
    }
}
fn push_i16(data: &[i16], target: &Arc<Mutex<Vec<f32>>>) {
    if let Ok(mut buffer) = target.lock() {
        buffer.extend(data.iter().map(|sample| *sample as f32 / i16::MAX as f32));
    }
}
fn push_u16(data: &[u16], target: &Arc<Mutex<Vec<f32>>>) {
    if let Ok(mut buffer) = target.lock() {
        buffer.extend(
            data.iter()
                .map(|sample| (*sample as f32 / u16::MAX as f32) * 2.0 - 1.0),
        );
    }
}

pub fn read_wav_samples(path: &std::path::Path) -> Result<(Vec<f32>, AudioSpec), String> {
    let mut reader = hound::WavReader::open(path)
        .map_err(|error| format!("无法读取 WAV 文件：{error}"))?;
    let wav_spec = reader.spec();
    if wav_spec.sample_format != hound::SampleFormat::Int || wav_spec.bits_per_sample != 16 {
        return Err("仅支持 16-bit PCM WAV 录音文件".into());
    }
    let samples = reader
        .samples::<i16>()
        .map(|sample| sample.map(|value| value as f32 / i16::MAX as f32))
        .collect::<Result<Vec<_>, _>>()
        .map_err(|error| format!("无法解码 WAV 音频：{error}"))?;
    Ok((
        samples,
        AudioSpec {
            sample_rate: wav_spec.sample_rate,
            channels: wav_spec.channels,
        },
    ))
}
