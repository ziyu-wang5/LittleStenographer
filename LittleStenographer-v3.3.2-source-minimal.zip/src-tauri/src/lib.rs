mod audio;
mod offline_asr;

use audio::RecordingHandle;
use serde::{Deserialize, Serialize};
use std::{fs, path::PathBuf, sync::Mutex};
use tauri::{AppHandle, Emitter, Manager, State};
use tauri_plugin_global_shortcut::{GlobalShortcutExt, Shortcut, ShortcutState};

struct AppState { recording: Mutex<Option<RecordingHandle>>, recognizer: Mutex<Option<offline_asr::SenseVoiceRecognizer>> }

#[derive(Clone, Serialize, Deserialize)]
struct Settings { hotkey: String, language: String }

#[derive(Serialize)]
struct RuntimeStatus { ready: bool, phase: String }

impl Default for Settings { fn default() -> Self { Self { hotkey: "Alt+Space".into(), language: "auto".into() } } }

fn settings_path(app: &AppHandle) -> Result<PathBuf, String> { Ok(app.path().app_config_dir().map_err(|e| e.to_string())?.join("settings.json")) }

#[tauri::command]
fn get_settings(app: AppHandle) -> Result<Settings, String> {
    let path = settings_path(&app)?;
    Ok(fs::read_to_string(path).ok().and_then(|s| serde_json::from_str(&s).ok()).unwrap_or_default())
}

#[tauri::command]
fn save_settings(app: AppHandle, settings: Settings) -> Result<(), String> {
    let path = settings_path(&app)?; if let Some(parent) = path.parent() { fs::create_dir_all(parent).map_err(|e| e.to_string())?; }
    fs::write(path, serde_json::to_vec_pretty(&settings).map_err(|e| e.to_string())?).map_err(|e| e.to_string())
}

#[tauri::command]
fn get_runtime_status(state: State<'_, AppState>) -> RuntimeStatus { RuntimeStatus { ready: state.recognizer.lock().map(|r| r.is_some()).unwrap_or(false), phase: "本地 SenseVoiceSmall".into() } }

fn resource_dir(app: &AppHandle) -> Result<PathBuf, String> { app.path().resource_dir().map_err(|e| e.to_string()) }

fn ensure_recognizer(app: &AppHandle, state: &AppState, language: &str) -> Result<(), String> {
    let mut guard = state.recognizer.lock().map_err(|_| "识别器状态不可用".to_string())?;
    if guard.is_none() { *guard = Some(offline_asr::SenseVoiceRecognizer::create(language, &resource_dir(app)?)?); }
    Ok(())
}

fn set_clipboard(text: &str) -> Result<(), String> {
    #[cfg(target_os = "windows")]
    { use std::process::Command; let escaped = text.replace('"', "``\""); Command::new("powershell").args(["-NoProfile", "-Command", &format!("Set-Clipboard -Value \"{}\"", escaped)]).status().map_err(|e| e.to_string())?.success().then_some(()).ok_or_else(|| "无法写入剪贴板".into()) }
    #[cfg(not(target_os = "windows"))] { let _ = text; Err("当前最小版仅支持 Windows".into()) }
}

#[tauri::command]
fn copy_text(text: String) -> Result<(), String> { set_clipboard(&text) }

#[tauri::command]
fn recordings_directory(app: AppHandle) -> Result<String, String> { Ok(app.path().app_data_dir().map_err(|e| e.to_string())?.join("recordings").to_string_lossy().into_owned()) }

#[tauri::command]
fn start_recording(app: AppHandle, state: State<'_, AppState>) -> Result<(), String> {
    let mut recording = state.recording.lock().map_err(|_| "录音状态不可用".to_string())?;
    if recording.is_some() { return Ok(()); }
    *recording = Some(audio::start()?); let _ = app.emit("recording-state", true); Ok(())
}

#[tauri::command]
fn stop_recording(app: AppHandle, state: State<'_, AppState>) -> Result<String, String> {
    let handle = state.recording.lock().map_err(|_| "录音状态不可用".to_string())?.take().ok_or("当前没有正在录音")?;
    let (samples, spec) = audio::stop(handle)?;
    let settings = get_settings(app.clone())?; ensure_recognizer(&app, &state, &settings.language)?;
    let text = state.recognizer.lock().map_err(|_| "识别器状态不可用".to_string())?.as_ref().and_then(|r| samples.lock().ok().and_then(|s| r.transcribe(&s, &spec))).unwrap_or_default();
    let _ = app.emit("recording-state", false); Ok(text)
}

#[tauri::command]
fn transcribe_selected_recording(app: AppHandle, state: State<'_, AppState>, path: String) -> Result<String, String> {
    let (samples, spec) = audio::read_wav_samples(std::path::Path::new(&path))?; let settings = get_settings(app.clone())?; ensure_recognizer(&app, &state, &settings.language)?;
    Ok(state.recognizer.lock().map_err(|_| "识别器状态不可用".to_string())?.as_ref().and_then(|r| r.transcribe(&samples, &spec)).unwrap_or_default())
}

pub fn run() {
    tauri::Builder::default()
        .manage(AppState { recording: Mutex::new(None), recognizer: Mutex::new(None) })
        .plugin(tauri_plugin_global_shortcut::Builder::new().with_handler(|app, shortcut, event| {
            if shortcut == &"Alt+Space".parse::<Shortcut>().unwrap() {
                if event.state == ShortcutState::Pressed { let _ = app.emit("shortcut-recording", true); }
                else { let _ = app.emit("shortcut-recording", false); }
            }
        }).build())
        .invoke_handler(tauri::generate_handler![get_settings, save_settings, get_runtime_status, copy_text, recordings_directory, start_recording, stop_recording, transcribe_selected_recording])
        .setup(|app| { app.global_shortcut().register("Alt+Space").map_err(|e| e.to_string())?; Ok(()) })
        .run(tauri::generate_context!()).expect("error while running tauri application");
}
