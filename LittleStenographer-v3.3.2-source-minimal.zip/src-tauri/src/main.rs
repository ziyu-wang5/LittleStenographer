// Build this desktop application as a native Windows GUI process. This keeps
// the program independent of a VBS launcher: double-clicking the EXE or using
// its Start Menu shortcut never creates a Command Prompt window.
#![cfg_attr(target_os = "windows", windows_subsystem = "windows")]

fn main() {
    little_stenographer_minimal_lib::run();
}
