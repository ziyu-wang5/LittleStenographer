use crate::audio::AudioSpec;
use sherpa_onnx::{OfflineRecognizer, OfflineRecognizerConfig, OfflineSenseVoiceModelConfig};
use std::path::{Path, PathBuf};

pub struct SenseVoiceRecognizer { recognizer: OfflineRecognizer }

impl SenseVoiceRecognizer {
    pub fn create(language: &str, resource_dir: &Path) -> Result<Self, String> {
        let model = locate(resource_dir, "model.int8.onnx")
            .ok_or_else(|| "未找到 SenseVoiceSmall 模型，请查看 MODEL_SETUP.md".to_string())?;
        let tokens = locate(resource_dir, "tokens.txt")
            .ok_or_else(|| "未找到 SenseVoice tokens.txt，请查看 MODEL_SETUP.md".to_string())?;
        let mut config = OfflineRecognizerConfig::default();
        config.model_config.tokens = Some(tokens.to_string_lossy().into_owned());
        config.model_config.num_threads = std::thread::available_parallelism()
            .map(|n| n.get().clamp(2, 8) as i32).unwrap_or(4);
        config.model_config.sense_voice = OfflineSenseVoiceModelConfig {
            model: Some(model.to_string_lossy().into_owned()),
            language: Some(match language { "zh" | "en" => language, _ => "auto" }.into()),
            use_itn: true,
        };
        let recognizer = OfflineRecognizer::create(&config)
            .ok_or_else(|| "无法加载 SenseVoiceSmall int8 模型".to_string())?;
        Ok(Self { recognizer })
    }

    pub fn transcribe(&self, samples: &[f32], spec: &AudioSpec) -> Option<String> {
        if samples.is_empty() { return None; }
        let mono = downmix(samples, spec.channels);
        let stream = self.recognizer.create_stream();
        stream.accept_waveform(spec.sample_rate as i32, &mono);
        self.recognizer.decode(&stream);
        stream.get_result().map(|r| r.text.trim().to_string()).filter(|t| !t.is_empty())
    }
}

fn downmix(samples: &[f32], channels: u16) -> Vec<f32> {
    let channels = channels.max(1) as usize;
    if channels == 1 { return samples.to_vec(); }
    samples.chunks_exact(channels).map(|frame| frame.iter().sum::<f32>() / channels as f32).collect()
}

fn locate(resource_dir: &Path, filename: &str) -> Option<PathBuf> {
    [
        resource_dir.join("models/sensevoice").join(filename),
        resource_dir.join("sensevoice").join(filename),
        PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("resources/models/sensevoice").join(filename),
    ].into_iter().find(|p| p.exists())
}
