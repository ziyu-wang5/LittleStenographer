Place the licensed SenseVoiceSmall model.int8.onnx and tokens.txt here before building a distributable installer.
